/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package dao;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.product;

/**
 *
 * @author Yogesh
 */
public class ProductDao {
    public static void save(product product){
        String query = "insert into product(name,category,price,quantity) values('"+product.getName()+"','"+product.getCategory()+"','"+product.getPrice()+"','"+product.getQuantity()+"')";
        DbOperations.setDataOrDelete(query, "Product Addded Successfully");
    }

    public  static  ArrayList<product> getAllRecords(){
        ArrayList<product> arrayList = new ArrayList<product>();
        try{
            ResultSet rs = DbOperations.getData("select *from product");
            while(rs.next()){
                product product = new product();
                product.setId(rs.getInt("id"));
                product.setName(rs.getString("name"));
                product.setCategory(rs.getString("category"));
                product.setPrice(rs.getString("price"));
                product.setQuantity(rs.getString("quantity"));
                arrayList.add(product);
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        return arrayList;

    }

    public static void update(product product){
        String query = "update product set name = '"+product.getName()+"',category = '"+product.getCategory()+"',price = '"+product.getPrice()+"',quantity = '"+product.getQuantity()+"' where id = '"+product.getId()+"'";
        DbOperations.setDataOrDelete(query,"Product Update Successfully");

    }
      public static void delete(String id){
          String query = "delete from product where id = '"+id+"'";
          DbOperations.setDataOrDelete(query,"Product Deleted Successfully");
      }

      public static ArrayList<product> filterProductByname(String name,String category){
          ArrayList<product> arrayList = new ArrayList<product>();
      try{
          ResultSet rs = DbOperations.getData("select *from product where name like '%"+name+"%' and category ='"+category+"'");
          while(rs.next()){
              product product = new  product();
              product.setName(rs.getString("name"));
              arrayList.add(product);
          }
      }
      catch(Exception e){
          JOptionPane.showMessageDialog(null, e);

      }
      return arrayList;
    }

      public static product getProductByname(String name){
          product product = new product();
          try{
              ResultSet rs = DbOperations.getData("select *from product where name='"+name+"'");
              while(rs.next()){
                  product.setName(rs.getString(2));
                  product.setCategory(rs.getString(3));
                  product.setPrice(rs.getString(4));
              }
          }
          catch(Exception e){
              JOptionPane.showMessageDialog(null, e);
          }
          return product;
      }


      public static ArrayList<product> getAllRecordsByCategory(String category){
          ArrayList<product> arrayList = new ArrayList<product>();
          try{
              ResultSet rs = DbOperations.getData("select *from product where category='"+category+"'");
              while(rs.next()){
                  product product = new product();
                  product.setName(rs.getString("name"));
                  arrayList.add(product);
              }
          }
          catch(Exception e){
              JOptionPane.showMessageDialog(null,e);

          }
          return arrayList;
      }
}
